package com.dbs.challenge;

import org.apache.commons.jexl3.*;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

public class DbsChallengeHelper {

    public static final String SUPPORTED_OPERATORS = "+-*/()";
    private static final JexlEngine jexl = new JexlBuilder().cache(512).strict(true).silent(false).create();

    public static List<Node> sort(List<Node> graph) throws DbsChallengeException {
        // map to save in-degree
        HashMap<Node, Integer> map = new HashMap<>();
        for (Node node : graph) {
            for (Node neighbor : node.getNeighbors()) {
                if (map.containsKey(neighbor)) {
                    map.put(neighbor, map.get(neighbor) + 1);
                } else {
                    map.put(neighbor, 1);
                }
            }
        }

        ArrayList<Node> result = new ArrayList<>();

        Queue<Node> q = new LinkedList<>();
        for (Node node : graph) {
            if (!map.containsKey(node)) {
                q.offer(node);
                result.add(node);
            }
        }

        while (!q.isEmpty()) {
            Node node = q.poll();
            for (Node n : node.getNeighbors()) {
                map.put(n, map.get(n) - 1);
                // if in-degree == 0, put it into queue
                if (map.get(n) == 0) {
                    result.add(n);
                    q.offer(n);
                }
            }
        }

        // has cycle
        if (result.size() != graph.size()) {
            throw new DbsChallengeException();
        }

        return result;
    }

    static BigDecimal eval(String formula, Map<String, BigDecimal> valueMap) {
        JexlExpression e = jexl.createExpression(formula);

        // populate the context
        JexlContext context = new MapContext();
        for (Map.Entry<String, BigDecimal> entry : valueMap.entrySet()) {
            context.set(entry.getKey(), entry.getValue().doubleValue());
        }
        // work it out
        Object result = e.evaluate(context);

        return newValueWithScale(String.valueOf(result));
    }

    public static BigDecimal newValueWithScale(String s) {
        return new BigDecimal(s).setScale(5, RoundingMode.HALF_UP);
    }

    public static void parseLine(String st, char row, Map<String, Node> nodes) {
        String line = StringUtils.trimToEmpty(st);
        String[] columns = StringUtils.split(line, ',');
        for (int i = 0; i < columns.length; i++) {
            String expression = columns[i];
            String label = String.format("%c%d", row, i);
            Node node = nodes.containsKey(label) ? nodes.get(label) : new Node(label, expression);
            node.setExpression(expression);
            if (expression.startsWith("=")) {
                String[] colValExs = StringUtils.split(expression.substring(1), SUPPORTED_OPERATORS);

                for (String item : colValExs) {
                    // ref
                    if (Character.isLetter(item.charAt(0))) {
                        if (nodes.containsKey(item)) {
                            nodes.get(item).getNeighbors().add(node);
                        } else {
                            Node temp = new Node(item);
                            nodes.put(item, temp);

                            temp.getNeighbors().add(node);
                        }
                    }
                }
            } else {
                node.setValue(DbsChallengeHelper.newValueWithScale(expression));
            }
            nodes.put(label, node);
        }
    }
}

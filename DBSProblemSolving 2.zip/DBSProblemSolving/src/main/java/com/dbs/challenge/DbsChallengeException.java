package com.dbs.challenge;

public class DbsChallengeException extends Exception {

    public DbsChallengeException() {
        super("Cyclic dependency error. Some nodes depend on each other.");
    }
}
